package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Person;
import com.example.demo.model.User;
import com.example.demo.service.PersonService;
import com.example.demo.service.UserService;

@RestController

public class UserController {

	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/createUser", method = RequestMethod.POST)
	public String create(@RequestParam String phoneNo,@RequestParam  String googleName,@RequestParam  String googleEmail,@RequestParam  String googleImgUrl,@RequestParam  String fbName,@RequestParam  String fbEmail, @RequestParam String fbImgUrl ) {
		User u = userService.create(phoneNo,googleName, googleEmail, googleImgUrl, fbName, fbEmail, fbImgUrl );
		return u.toString();
	}
	
	@RequestMapping(value = "/getAllusers", method = RequestMethod.GET)
	public List<User> getAll(){
		return userService.getAll();
	}
	@RequestMapping(value = "/updateUserPhnoById", method = RequestMethod.PUT)
	public String update(@RequestParam int id,@RequestParam String phoneNo) {
		User u = userService.update(id, phoneNo);
		return u.toString();
	}
	@RequestMapping(value = "/deleteUserById", method = RequestMethod.DELETE)
	public String delete(@RequestParam int id) {
		userService.delete(id);
		return "Deleted "+id;
	}
	@RequestMapping (value = "/deleteAllUsers", method = RequestMethod.DELETE)
	public String deleteAll() {
		userService.deleteAll();
		return "Deleted all records";
	}
	
}