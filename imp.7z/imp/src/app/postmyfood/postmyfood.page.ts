import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postmyfood',
  templateUrl: './postmyfood.page.html',
  styleUrls: ['./postmyfood.page.scss'],
})
export class PostmyfoodPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
