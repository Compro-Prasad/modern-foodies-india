import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chefinfo',
  templateUrl: './chefinfo.page.html',
  styleUrls: ['./chefinfo.page.scss'],
})
export class ChefinfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
