import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ifchef',
  templateUrl: './ifchef.page.html',
  styleUrls: ['./ifchef.page.scss'],
})
export class IfchefPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
